<template>
  <div class="text-center mt-12 text-gray-700">
    <h1 class="text-4xl font-bold">404</h1>
    <p class="mt-2 text-lg">The page you are looking for was not found.</p>
    <RouterLink to="/" class="text-blue-500 mt-4 inline-block">Go back to Home</RouterLink>
  </div>
</template>
