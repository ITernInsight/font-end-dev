<script setup lang="ts">
import { ref, onMounted, computed } from 'vue';
import { RouterLink, useRouter } from 'vue-router';
import axios from 'axios';
import Filter from '../components/FilterComp.vue';

interface Review {
  id: number;
  title: string;
  position?: string;
  description: string;
  date: Date;
  company?: string;
  userName?: string;
  likedByUser?: boolean;
  likeCount?: number;
}

const reviews = ref<Review[]>([]);
const isLoading = ref(true);
const searchKeyword = ref('');
const selectedPosition = ref('');
const startDate = ref('');
const endDate = ref('');
const router = useRouter();
const showingMyReviews = ref(false); 

const isTokenValid = () => {
  const token = localStorage.getItem('token');
  if (!token) return false;
  const payload = JSON.parse(atob(token.split('.')[1]));
  const currentTime = Math.floor(Date.now() / 1000);
  return payload.exp > currentTime;
};

if (!isTokenValid()) {
  alert('Session expired. Please log in again.');
  localStorage.removeItem('token');
  router.push('/login');
}

const fetchAllReviews = async () => {
  try {
    const token = localStorage.getItem('token');
    if (!token) throw new Error('Unauthorized: No token found');

    const response = await axios.get('http://localhost:3000/reviews', {
      headers: { Authorization: `Bearer ${token}` },
    });
    reviews.value = response.data;
    showingMyReviews.value = false; // ตั้งค่าว่ากำลังแสดงรีวิวทั้งหมด
  } catch (error) {
    console.error('Error fetching data', error);
  } finally {
    isLoading.value = false;
  }
};

const fetchMyReviews = async () => {
  try {
    isLoading.value = true;
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    if (!token || !user) throw new Error('Unauthorized');

    const userId = JSON.parse(user).id;

    const response = await axios.get(`http://localhost:3000/reviews/user/${userId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    reviews.value = response.data;
    showingMyReviews.value = true; 
  } catch (error) {
    console.error('Error fetching my reviews:', error);
  } finally {
    isLoading.value = false;
  }
};

const toggleLike = async (review: Review) => {
  try {
    const token = localStorage.getItem('token');
    if (!token) throw new Error('Unauthorized');

    await axios.post(`http://localhost:3000/reviews/${review.id}/like`, {}, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    // สลับสถานะ + ปรับยอดไลค์
    if (review.likedByUser) {
      review.likedByUser = false;
      review.likeCount = (review.likeCount ?? 1) - 1;
    } else {
      review.likedByUser = true;
      review.likeCount = (review.likeCount ?? 0) + 1;
    }
  } catch (error) {
    console.error('Error toggling like:', error);
  }
};



const positions = computed(() => {
  const uniquePositions = new Set(reviews.value.map((review) => review.position).filter(Boolean));
  return Array.from(uniquePositions) as string[];
});

const filteredReviews = computed(() => {
  return reviews.value.filter((review) => {
    const matchesSearch =
      review.title.toLowerCase().includes(searchKeyword.value.toLowerCase()) ||
      review.description.toLowerCase().includes(searchKeyword.value.toLowerCase());

    const matchesPosition = !selectedPosition.value || review.position === selectedPosition.value;

    const reviewDate = new Date(review.date);
    const matchesDateRange =
      (!startDate.value || reviewDate >= new Date(startDate.value)) &&
      (!endDate.value || reviewDate <= new Date(endDate.value));

    return matchesSearch && matchesPosition && matchesDateRange;
  });
});

const sortedReviews = computed(() => {
  return filteredReviews.value.slice().sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
});

onMounted(fetchAllReviews); // เริ่มต้นโหลดรีวิวทั้งหมด
</script>

<template>
  <div class="flex justify-end gap-4 px-16 mt-4">
    <RouterLink
      :to="{ path: '/admin/add-review', query: { from: 'user' } }"
      class="bg-gradient-to-b from-button to-button/50 text-white px-4 py-2 rounded-lg shadow-md"
    >
      Add review
    </RouterLink>

    <button
      v-if="showingMyReviews"
      @click="fetchAllReviews"
      class="bg-gradient-to-b from-button to-button/50 text-white px-4 py-2 rounded-lg shadow-md"
    >
      All Reviews
    </button>
    <button
      v-else
      @click="fetchMyReviews"
      class="bg-gradient-to-b from-button to-button/50 text-white px-4 py-2 rounded-lg shadow-md"
    >
      My Reviews
    </button>
  </div>

  <Filter
    class="mt-4"
    @updateSearch="searchKeyword = $event"
    @updatePosition="selectedPosition = $event"
    @updateStartDate="startDate = $event"
    @updateEndDate="endDate = $event"
    :positions="positions"
  />

  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 px-16 mt-8 mb-8">
    <div
      v-for="review in sortedReviews"
      :key="review.id"
      class="border border-border p-4 rounded-lg bg-white shadow"
    >
      <h2 class="text-lg font-bold text-hightlight truncate">{{ review.title }}</h2>
      <p v-if="review.company" class="text-sm font-medium text-gray-600 truncate">{{ review.company }}</p>
      <p v-else-if="review.position" class="text-sm font-medium text-gray-600 truncate">{{ review.position }}</p>
      <p class="text-sm mt-2 text-gray-700 line-clamp-2">{{ review.description.substring(0, 60) }}...</p>
      <small class="text-xs text-gray-400">{{ new Date(review.date).toLocaleDateString('en-GB') }}</small>
      <div class="flex justify-between items-center mt-3">
        <RouterLink
          :to="`reviews/${review.id}`"
          class="text-xs font-medium text-white bg-gradient-to-b from-button to-button/40 px-4 py-1 rounded-lg border-border border shadow-sm md:text-sm lg:text-base"
        >
          Read more
        </RouterLink>

        <div v-for="review in reviews" :key="review.id" class="review-box">
  <h3>{{ review.title }}</h3>
  <p>{{ review.description }}</p>

  <!-- ✅ ปุ่มกดไลค์ + จำนวน -->
  <button @click="toggleLike(review)">
    {{ review.likedByUser ? '💖 Liked' : '🤍 Like' }} ({{ review.likeCount || 0 }})
  </button>
</div>

      </div>
    </div>
  </div>

  <div v-if="sortedReviews.length === 0 && !isLoading" class="flex flex-col items-center justify-center py-12">
    <p class="text-gray-500 font-medium">No reviews found</p>
  </div>

  <div v-if="isLoading" class="flex justify-center py-12">
    <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-hightlight"></div>
  </div>
</template>